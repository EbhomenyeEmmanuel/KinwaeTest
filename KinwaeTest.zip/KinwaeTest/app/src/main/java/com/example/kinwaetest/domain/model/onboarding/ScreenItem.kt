package com.example.kinwaetest.domain.model.onboarding

data class ScreenItem(val title: String, val description: String, val screenImage: Int)
