package com.example.kinwaetest.utils

object Constants {

}